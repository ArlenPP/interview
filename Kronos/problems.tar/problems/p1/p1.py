from datetime import datetime

def quarterly(cur_time):
    """ Return the expiry date in string format
    Args:
        cur_time(datetime): input datetime
    """
    expiry = ''
    return expiry


if __name__ == '__main__':
    assert quarterly(datetime(2020, 1, 27)) == '200327'
    assert quarterly(datetime(2019, 11, 1)) == '191227'
    assert quarterly(datetime(2019, 12, 27)) == '200327'
    assert quarterly(datetime(2019, 12, 1)) == '191227'
    assert quarterly(datetime(2019, 12, 18)) == '200327'
