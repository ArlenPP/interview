#include <iostream>
#include <vector>
#include <cassert>

int solve(const std::vector<int> &&input, const int num_servers)
{
	// Please implement here
	return 0;
}

#ifndef KRONOS_TEST
int main()
{
	assert(solve({3, 4, 5, 6}, 3) == 7);
	assert(solve({1, 2, 3, 4}, 3) == 4);
	assert(solve({3, 2, 3, 4, 2, 1}, 4) == 4);
	return 0;
}
#endif
